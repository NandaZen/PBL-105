const ctx = document.getElementById('myChart').getContext('2d');
const myChart = new Chart(ctx, {
  type: 'bar',
  data: {
    labels: ['Beras', 'Roti', 'Ale-ale', 'Gula', 'Chuba', 'Kopi', 'Susu' , 'Teh'], 
    datasets: [
      {
        label: 'Bahan Baku Masuk',
        data: [180, 100, 150, 80, 78,12,16,99],
        backgroundColor: 'rgba(54, 162, 235, 0.7)',
      },
      {
        label: 'Bahan Baku Keluar',
        data: [40, 15, 55, 10, 45,10,16,89],
        backgroundColor: 'rgba(153, 102, 255, 0.7)',
      }
    ]
  },
  options: {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
      }
    },
    plugins:{
      legend:{
        position:'bottom'
      }
    }
  }
});

function openSidebar() {
  document.getElementById("sidebar").style.width = "250px"; // Buka sidebar
  document.querySelector(".main-content").style.marginLeft = "250px"; // Pindahkan konten utama
  document.querySelector(".navbar").style.marginLeft = "250px"; // Pindahkan navbar
}

function closeSidebar() {
  document.getElementById("sidebar").style.width = "0"; // Tutup sidebar
  document.querySelector(".main-content").style.marginLeft = "0"; // Reset margin konten utama
  document.querySelector(".navbar").style.marginLeft = "0"; // Reset margin navbar
}